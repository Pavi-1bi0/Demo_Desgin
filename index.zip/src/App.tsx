import './App.css'
import SoftwareDashboard from './components/dashboard/dashboard'

function App() {

  return (
    <>
      <SoftwareDashboard/>
    </>
  )
}

export default App
