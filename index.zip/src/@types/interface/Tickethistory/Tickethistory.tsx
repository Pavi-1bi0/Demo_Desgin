interface TicketHistoryProps {
    selectedCard: { name: string; lastReviewDate: string; lorem: string } | null;
}

export default TicketHistoryProps;