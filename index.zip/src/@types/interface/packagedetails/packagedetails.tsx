interface User {
    id: number;
    name: string;
    status: string;
    department: string;
    email: string;
}

export default User;